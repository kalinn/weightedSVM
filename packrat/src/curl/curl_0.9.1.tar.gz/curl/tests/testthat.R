library(testthat)
library(curl)

test_check("curl")
